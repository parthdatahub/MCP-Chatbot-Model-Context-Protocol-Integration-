# MCP Chatbot Setup

1. Create a virtual environment
2. Install dependencies
3. Configure your .env file
4. Run `streamlit run app.py`
